package com.weather.service;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.weather.model.WeatherDAO;
import com.weather.model.WeatherVO;

public class ContentServiceImpl implements WeatherService{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		HttpSession session = request.getSession();
		String city = (String)session.getAttribute("city");
		
		WeatherDAO dao = WeatherDAO.getInstance();
		WeatherVO vo = dao.getContent(city);
	
		request.setAttribute("vo", vo);
	}

}
