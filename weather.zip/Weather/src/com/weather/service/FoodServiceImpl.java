package com.weather.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.weather.model.WeatherDAO;
import com.weather.model.WeatherVO;

public class FoodServiceImpl implements WeatherService{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		WeatherVO vo= (WeatherVO)request.getAttribute("vo");		
		WeatherDAO dao = WeatherDAO.getInstance();		
		dao.food(vo.getAvg_temp(),vo.getWeather());
		
	}

}
