package com.weather.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface WeatherService {
	public void execute(HttpServletRequest request, HttpServletResponse response);
}
