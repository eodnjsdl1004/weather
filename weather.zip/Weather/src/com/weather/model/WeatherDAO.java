package com.weather.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.weather.util.JdbcUtil;


public class WeatherDAO {
	
	//DAO에 회원관리에 필요한 기능을 메서드로 생성, DB관련변수를 멤버변수로 선언	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	private DataSource ds;
	
	private static WeatherDAO instance = new WeatherDAO();
	
	private WeatherDAO() {
		
		try {
			InitialContext ct = new InitialContext();
			ds = (DataSource) ct.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("클래스 로딩중 에러");
		}
	}
	
	//3. 외부에서 객체생성을 요구할 때 getter메서드를 통해 반환함
	public static WeatherDAO getInstance() {
		return instance;
	}
	
	
	public int regist(WeatherVO vo) {	
		int result = 0;

		String sql = "insert into weather(wno, city, weather, humidity, temp_max, temp_min, speed, avg_temp) values (weather_seq.nextval,?,?,?,?,?,?,?)";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getCity() );
			pstmt.setString(2, vo.getWeather() );
			pstmt.setString(3, vo.getHumidity() );
			pstmt.setString(4, vo.getTemp_max() );
			pstmt.setString(5, vo.getTemp_min() );
			pstmt.setString(6, vo.getAvg_temp());
			pstmt.setString(7, vo.getSpeed() );
			result = pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();	
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		return result;
	}
	
	
	public int food(String avg_temp,String weather) {	
		int result = 0;
		String food = "";
		
		int avg = Integer.parseInt(avg_temp);
		
		if(weather.equals("rain")){
			food = "칼국수";
		}else if(15<=avg&&avg<=20) {
			food = "호떡";
		}else if(15>=avg) {
			food ="순대국밥";
		}else if(30>=avg&&avg>=25) {
			food ="냉면";
		}else if(avg>=35) {
			food ="팥빙수";
		} else {
			food = "닭갈비";
		}


		String sql = "insert into food(fno, avg_temp, food) values (food_seq.nextval,?,?)";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, String.valueOf(avg));
			pstmt.setString(2, food);
			
			result = pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();	
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		return result;
	}
	
	public WeatherVO getContent(String city) {
		WeatherVO vo = new WeatherVO();
		
		String sql = "select * from weather where city = ?";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, city);			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				vo = new WeatherVO(rs.getInt("wno"), rs.getString("city"), rs.getString("weather"),rs.getString("humidity"), rs.getString("temp_max"), rs.getString("temp_min"), rs.getString("speed"),rs.getString("avg_temp"), rs.getTimestamp("regdate"));
				
			}
		} catch (Exception e) {
			
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		return vo;
	}
	

	
}
