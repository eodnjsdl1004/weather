create table weather(

    wno number(10,0) not null,
    city varchar2(30) not null,
    weather varchar2(30),
    humidity varchar2(30),
    temp_max varchar2(30),
    temp_min varchar2(30),
    speed varchar2(30),
    regdate date default sysdate,
);
alter table weather add constraint wno_pk primary key(wno);

create sequence weather_seq;